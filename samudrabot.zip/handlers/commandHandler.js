const { isAdmin } = require("./roleHandler");

async function handleCommand(sock, sender, text, config) {
    const command = text.trim().split(" ")[0].toLowerCase();

    switch (command) {
        case "/menu":
            await sock.sendMessage(sender, {
                text:
`📜 *SAMUDRABOT MENU UTAMA*

🧠 AI Assistant
├─ 💬 Tanya AI → kirim pertanyaan biasa (tanpa prefix)
├─ 🧹 /reset → Hapus riwayat kamu

📷 Media Tools
├─ 🔍 /carifoto <query> → Cari gambar dari internet *(Coming soon)*

👤 Informasi
├─ 👑 /owner → Info pemilik bot
├─ 📄 /menu → Tampilkan menu ini

🛡 Admin Tools
├─ 📋 /listuser → Lihat semua pengguna *(Admin Only)*`
            });
            break;

        case "/owner":
            await sock.sendMessage(sender, { text: `👑 Pemilik bot ini adalah: ${config.owner}` });
            break;

        case "/reset":
            const fs = require("fs");
            const path = require("path");
            const file = path.join(__dirname, "..", "database", "users.json");
            if (fs.existsSync(file)) {
                let db = JSON.parse(fs.readFileSync(file));
                delete db[sender];
                fs.writeFileSync(file, JSON.stringify(db, null, 2));
            }
            await sock.sendMessage(sender, { text: "✅ Riwayat kamu sudah direset!" });
            break;

        case "/listuser":
            if (!isAdmin(sender, config.admins)) {
                await sock.sendMessage(sender, { text: "🚫 Perintah khusus admin!" });
                return;
            }
            const users = require("fs").readdirSync("./database");
            const db = require("../database/users.json");
            const list = Object.keys(db).map((u, i) => `${i + 1}. ${u}`).join("\n");
            await sock.sendMessage(sender, { text: `👥 *Pengguna Terdaftar:*\n${list}` });
            break;

        case "/carifoto":
            const { getImageFromUnsplash } = require("../utils/imageFetcher");
            const query = text.split(" ").slice(1).join(" ");
            if (!query) {
                await sock.sendMessage(sender, { text: "⚠️ Contoh penggunaan: /carifoto kucing lucu" });
                break;
            }
            const imgUrl = await getImageFromUnsplash(query);
            if (imgUrl) {
                await sock.sendMessage(sender, {
                    image: { url: imgUrl },
                    caption: `📸 Hasil pencarian: ${query}`
                });
            } else {
                await sock.sendMessage(sender, { text: "❌ Gagal menemukan gambar." });
            }
            break;

        default:
            await sock.sendMessage(sender, { text: "❓ Perintah tidak dikenal. Ketik /menu untuk bantuan." });
    }
}

module.exports = { handleCommand };