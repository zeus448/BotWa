function isAdmin(sender, adminList) {
    return adminList.includes(sender);
}

module.exports = { isAdmin };