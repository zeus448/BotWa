const { isAdmin } = require("./roleHandler");
const { handleCommand } = require("./commandHandler");
const { askChatGPT } = require("../utils/chatgpt");
const fs = require("fs");
const path = require("path");

const historyPath = path.join(__dirname, "..", "database", "users.json");

function saveHistory(sender, message) {
    let db = {};
    if (fs.existsSync(historyPath)) {
        db = JSON.parse(fs.readFileSync(historyPath));
    }
    if (!db[sender]) db[sender] = [];
    db[sender].push({ message, at: new Date().toISOString() });
    fs.writeFileSync(historyPath, JSON.stringify(db, null, 2));
}

async function handleMessage(sock, message, config) {
    const sender = message.key.remoteJid;
    const fromMe = message.key.fromMe;
    const text = message.message?.conversation || message.message?.extendedTextMessage?.text;

    if (!text) return;

    saveHistory(sender, text);

    if (text.startsWith("/")) {
        await handleCommand(sock, sender, text, config);
    } else {
        const reply = await askChatGPT(text, config.openai_key);
        await sock.sendMessage(sender, { text: reply });
    }
}

module.exports = { handleMessage };