# 🤖 SamudraBot

Bot WhatsApp pintar dengan AI (ChatGPT) + sistem admin + riwayat percakapan.

## 🚀 Cara Menjalankan

1. Clone atau download project ini
2. Jalankan:

\`\`\`bash
npm install
node index.js
\`\`\`

3. Scan QR Code yang muncul
4. Edit \`config/settings.json\`:
   - Tambahkan nomor admin kamu
   - Masukkan OpenAI API Key kamu

## ✨ Fitur
- Jawaban AI (ChatGPT)
- Menu & perintah via chat
- Sistem admin/user
- Penyimpanan history per user

> Dibuat oleh **SAMUDRA dari LOMBOK**
