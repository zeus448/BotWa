function logEvent(type, message) {
    console.log(\`[\${new Date().toISOString()}] [\${type.toUpperCase()}] \${message}\`);
}

module.exports = { logEvent };