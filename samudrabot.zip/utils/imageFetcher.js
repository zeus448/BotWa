const fetch = require("node-fetch");

async function getImageFromUnsplash(query) {
    try {
        const res = await fetch(`https://source.unsplash.com/600x400/?${encodeURIComponent(query)}`);
        return res.url;
    } catch (err) {
        console.error("Gagal ambil gambar:", err.message);
        return null;
    }
}

module.exports = { getImageFromUnsplash };
