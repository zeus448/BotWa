const axios = require("axios");

async function askChatGPT(message, apiKey) {
    try {
        const res = await axios.post(
            "https://api.openai.com/v1/chat/completions",
            {
                model: "gpt-3.5-turbo",
                messages: [{ role: "user", content: message }],
                temperature: 0.7,
            },
            {
                headers: {
                    Authorization: \`Bearer \${apiKey}\`,
                    "Content-Type": "application/json",
                },
            }
        );
        return res.data.choices[0].message.content.trim();
    } catch (err) {
        console.error("❌ Error AI:", err?.response?.data || err.message);
        return "⚠️ Maaf, AI sedang tidak tersedia.";
    }
}

module.exports = { askChatGPT };