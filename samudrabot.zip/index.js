const makeWASocket = require("@whiskeysockets/baileys").default;
const { useSingleFileAuthState } = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const { join } = require("path");
const { default: P } = require("pino");

const { handleMessage } = require("./handlers/messageHandler");
const config = require("./config/settings.json");

const authFile = join(__dirname, "sessions", "auth_info.json");
const { state, saveState } = useSingleFileAuthState(authFile);

async function startBot() {
    const sock = makeWASocket({
        logger: P({ level: "silent" }),
        printQRInTerminal: true,
        auth: state,
        syncFullHistory: false,
    });

    sock.ev.on("creds.update", saveState);

    sock.ev.on("connection.update", (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === "close") {
            const shouldReconnect = (lastDisconnect?.error instanceof Boom) ? (lastDisconnect.error.output.statusCode !== 401) : true;
            if (shouldReconnect) startBot();
        } else if (connection === "open") {
            console.log("✅ SamudraBot connected");
        }
    });

    sock.ev.on("messages.upsert", async ({ messages, type }) => {
        if (type === "notify") {
            await handleMessage(sock, messages[0], config);
        }
    });
}

startBot();